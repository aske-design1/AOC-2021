module Day01 (part1, part2) where

import Data.List.Split (splitOn)


part1 :: String -> Int
part1 = foldl readIncrease 0 splitOn "\n"


part2 :: String -> Int
part2 _ = 0